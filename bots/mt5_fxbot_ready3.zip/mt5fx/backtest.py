import pandas as pd
from dataclasses import dataclass
from typing import List, Dict, Any
from .data import load_rates
from .strategy import ema_cross_with_trend, attach_atr
from .strategy_loader import compute_plugin_signal

@dataclass
class Trade:
    entry_time:str; exit_time:str; side:str; entry_price:float; exit_price:float; sl:float; tp:float; result:str

def _exit_hit_bar(side, row, tp, sl):
    if side=='long':
        if row['bid_h']>=tp: return 'tp'
        if row['bid_l']<=sl: return 'sl'
    else:
        if row['ask_l']<=tp: return 'tp'
        if row['ask_h']>=sl: return 'sl'
    return None

def backtest_once(cfg:dict, df:pd.DataFrame):
    s=cfg['strategy']
    sig=compute_plugin_signal(df, s['plugin_module'], s.get('plugin_function','generate_signals'), s.get('plugin_shift_next_bar',True)) if s.get('use_plugin',False) else ema_cross_with_trend(df, fast=s['fast_ema'], slow=s['slow_ema'], trend=s['trend_ema'])
    df=attach_atr(df, n=s['atr_period'])
    trades:List[Trade]=[]; pos=None
    for i in range(1,len(df)-1):
        row=df.iloc[i]; signal=int(sig.iloc[i])
        if pos is not None:
            hit=_exit_hit_bar(pos['side'], row, pos['tp'], pos['sl'])
            if hit:
                exit_price=row['bid_o'] if pos['side']=='long' else row['ask_o']
                trades.append(Trade(str(pos['time']), str(row['time']), pos['side'], pos['entry'], exit_price, pos['sl'], pos['tp'], hit))
                pos=None
        if pos is None and signal!=0 and pd.notna(row['ATR']) and row['ATR']>0:
            side='long' if signal>0 else 'short'; entry=row['ask_o'] if side=='long' else row['bid_o']
            sl=entry - s['atr_sl_mult']*row['ATR'] if side=='long' else entry + s['atr_sl_mult']*row['ATR']
            tp=entry + s['atr_tp_mult']*row['ATR'] if side=='long' else entry - s['atr_tp_mult']*row['ATR']
            pos={'side':side,'entry':entry,'sl':sl,'tp':tp,'time':df.iloc[i]['time']}
    tr_df=pd.DataFrame([t.__dict__ for t in trades])
    win=float((tr_df['result']=='tp').mean()) if not tr_df.empty else 0.0
    return {'trades':tr_df,'win_rate':win}

def run_backtest(cfg:dict)->Dict[str,Any]:
    g=cfg['general']; b=cfg['backtest']
    df=load_rates(g['symbol'], g['timeframe'], count=b['lookback'])
    res=backtest_once(cfg, df)
    summary={'symbol':g['symbol'],'timeframe':g['timeframe'],'trades':int(len(res['trades'])),'win_rate':round(res['win_rate']*100,2)}
    return {'summary':summary,'trades':res['trades']}
