import MetaTrader5 as mt5
from .utils import load_env, env

TIMEFRAME_MAP={'M1':mt5.TIMEFRAME_M1,'M2':mt5.TIMEFRAME_M2,'M3':mt5.TIMEFRAME_M3,'M4':mt5.TIMEFRAME_M4,'M5':mt5.TIMEFRAME_M5,'M6':mt5.TIMEFRAME_M6,'M10':mt5.TIMEFRAME_M10,'M12':mt5.TIMEFRAME_M12,'M15':mt5.TIMEFRAME_M15,'M20':mt5.TIMEFRAME_M20,'M30':mt5.TIMEFRAME_M30,'H1':mt5.TIMEFRAME_H1,'H2':mt5.TIMEFRAME_H2,'H3':mt5.TIMEFRAME_H3,'H4':mt5.TIMEFRAME_H4,'H6':mt5.TIMEFRAME_H6,'H8':mt5.TIMEFRAME_H8,'H12':mt5.TIMEFRAME_H12,'D1':mt5.TIMEFRAME_D1,'W1':mt5.TIMEFRAME_W1,'MN1':mt5.TIMEFRAME_MN1}

class MT5:
    def __init__(self):
        load_env(); self.path=env('MT5_PATH', required=True); self.login=env('MT5_LOGIN', required=True, cast=int)
        self.password=env('MT5_PASSWORD', required=True); self.server=env('MT5_SERVER', required=True)
        self.initialized=False
    def init(self):
        if not mt5.initialize(self.path): raise RuntimeError(f'initialize() failed: {mt5.last_error()}')
        if not mt5.login(self.login, password=self.password, server=self.server): raise RuntimeError(f'login() failed: {mt5.last_error()}')
        self.initialized=True
    def shutdown(self):
        if self.initialized: mt5.shutdown(); self.initialized=False
    def ensure_symbol(self, symbol:str):
        info=mt5.symbol_info(symbol)
        if info is None: raise RuntimeError(f'Symbol {symbol} not found')
        if not info.visible and not mt5.symbol_select(symbol, True): raise RuntimeError(f'symbol_select({symbol}) failed')
        return mt5.symbol_info(symbol)
    def timeframe(self, tf):
        if tf not in TIMEFRAME_MAP: raise ValueError('Unsupported timeframe')
        return TIMEFRAME_MAP[tf]
