import pandas as pd

def enrich_ohlc(df:pd.DataFrame)->pd.DataFrame:
    out=df.copy()
    mapping={'Open':'mid_o','High':'mid_h','Low':'mid_l','Close':'mid_c','open':'mid_o','high':'mid_h','low':'mid_l','close':'mid_c','Mid':'mid_c','mid':'mid_c'}
    for k,src in mapping.items():
        if k not in out.columns and src in out.columns: out[k]=out[src]
    if 'bid_c' in out.columns and 'ask_c' in out.columns:
        out.setdefault('Bid', out['bid_c']); out.setdefault('Ask', out['ask_c'])
    return out
